const assessmentfilled = new mongoose.Schema({
    
    content:[Object]
})